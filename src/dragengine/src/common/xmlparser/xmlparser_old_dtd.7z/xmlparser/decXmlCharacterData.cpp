/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlCharacterData.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlCharacterData
////////////////////////

// constructor, destructor
decXmlCharacterData::decXmlCharacterData( const char *data ){
	pData = NULL;
	try{
		SetData( data );
	}catch( const deException & ){
		if( pData ) delete [] pData;
		throw;
	}
}
decXmlCharacterData::~decXmlCharacterData(){
	if( pData ) delete [] pData;
}

// management
void decXmlCharacterData::SetData( const char *data ){
	if( ! data ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( data ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, data );
	if( pData ) delete [] pData;
	pData = newStr;
}
void decXmlCharacterData::AppendData( const char *data ){
	if( ! data ) DETHROW( deeInvalidParam );
	
	if( pData ){
		int olen = strlen( pData );
		int alen = strlen( data );
		
		char *newStr = new char[ olen + alen + 1 ];
		if( ! newStr ) DETHROW( deeOutOfMemory );
		strcpy( newStr, pData );
		strcpy( newStr + olen, data );
		if( pData ) delete [] pData;
		pData = newStr;
		
	}else{
		SetData( data );
	}
}

void decXmlCharacterData::AppendCharacter( char character ){
	if( pData ){
		int olen = strlen( pData );
		
		char *newStr = new char[ olen + 2 ];
		if( ! newStr ) DETHROW( deeOutOfMemory );
		strcpy( newStr, pData );
		newStr[ olen ] = character;
		newStr[ olen + 1 ] = '\0';
		if( pData ) delete [] pData;
		pData = newStr;
		
	}else{
		pData = new char[ 2 ];
		if( ! pData ) DETHROW( deeOutOfMemory );
		pData[ 0 ] = character;
		pData[ 1 ] = '\0';
	}
}

// visiting
void decXmlCharacterData::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitCharacterData( this );
}

// casting
bool decXmlCharacterData::CanCastToCharacterData(){
	return true;
}
decXmlCharacterData *decXmlCharacterData::CastToCharacterData(){
	return this;
}
