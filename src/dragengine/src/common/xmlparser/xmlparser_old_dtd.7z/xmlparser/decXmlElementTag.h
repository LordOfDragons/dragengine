/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLELEMENTTAG_H_
#define _DECXMLELEMENTTAG_H_

// includes
#include "decXmlContainer.h"

// predefinitions



/**
 * @brief XML Element Tag.
 *
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 */
class decXmlElementTag : public decXmlContainer{
private:
	char *pName, *pNamespace, *pLocalName;
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/** Creates a new xml element tag. */
	decXmlElementTag( const char *name );
	/** Cleans up the xml element tag. */
	~decXmlElementTag();
	/*@}*/
	
	/** @name Management */
	/*@{*/
	inline const char *GetName() const{ return (const char *)pName; }
	void SetName( const char *name );
	/** Retrieves the namespace part of the tag name. */
	inline const char *GetNamespace() const{ return (const char *)pNamespace; }
	/** Retrieves the local name part of the tag name. */
	inline const char *GetLocalName() const{ return (const char *)pLocalName; }
	/*@}*/
	
	/** @name Helper Functions */
	/*@{*/
	/** Retrieves the first element tag beeing a decXmlCharacterData or NULL otherwise. */
	decXmlCharacterData *GetFirstData() const;
	/** Retrieves the index-th element tag beeing a decXmlElementTag or NULL otherwise. */
	decXmlElementTag *GetElementIfTag( int index ) const;
	/** Retrieves the decXmlAttValue with the given name or NULL otherwise. */
	decXmlAttValue *FindAttribute( const char *name ) const;
	/*@}*/
	
	/** @name Visiting */
	/*@{*/
	void Visit( decXmlVisitor *visitor );
	/*@}*/
	
	/** @name Casting */
	/*@{*/
	virtual bool CanCastToElementTag();
	virtual decXmlElementTag *CastToElementTag();
	/*@}*/
private:
	void pBreakUpName();
};

// end of include only once
#endif
