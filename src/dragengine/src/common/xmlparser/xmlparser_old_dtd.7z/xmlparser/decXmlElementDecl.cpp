/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlElementDecl.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlElementDecl
///////////////////////////////////

// constructor, destructor
decXmlElementDecl::decXmlElementDecl( const char *name ){
	pName = NULL;
	pContentType = ectEmpty;
	try{
		SetName( name );
	}catch( const deException & ){
		if( pName ) delete [] pName;
		throw;
	}
}
decXmlElementDecl::~decXmlElementDecl(){
	if( pName ) delete [] pName;
}

// management
void decXmlElementDecl::SetName( const char *name ){
	if( ! name ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( name ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, name );
	if( pName ) delete [] pName;
	pName = newStr;
}
void decXmlElementDecl::SetContentType( eContentTypes contentType ){
	if( contentType < ectEmpty || contentType >= ECT_COUNT ) DETHROW( deeInvalidParam );
	pContentType = contentType;
}

// visiting
void decXmlElementDecl::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitElementDecl( this );
}

// casting
bool decXmlElementDecl::CanCastToElementDecl(){
	return true;
}
decXmlElementDecl *decXmlElementDecl::CastToElementDecl(){
	return this;
}
