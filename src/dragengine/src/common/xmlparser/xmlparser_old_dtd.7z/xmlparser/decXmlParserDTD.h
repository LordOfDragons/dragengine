/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLPARSERDTD_H_
#define _DECXMLPARSERDTD_H_

// includes


// predefinitions
class decXmlParser;
class decXmlDTD;
class decXmlElementDecl;
class decXmlElementDeclOp;
class decXmlAttListDecl;
class decXmlAttListDeclEntry;
class decXmlAttValue;


/**
 * @brief XML DTD Parser.
 *
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 * This parses uses a parent XML parser for token reading. Furthermore
 * this way the parsing of inline DTD declarations is easier.
 */
class decXmlParserDTD{
private:
	decXmlParser *pParent;
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/** Creates a new xml dtd parser using the given xml parser as parent. */
	decXmlParserDTD( decXmlParser *parent );
	/** Cleans up the xml dtd parser. */
	~decXmlParserDTD();
	/*@}*/
	
	/**
	 * @name Parsing Functions
	 * Those functions are used only by the ParseXml and should not be called
	 * directly except you want to write an extended XML parser.
	 */
	/*@{*/
	/** Parses a DTD declaration. */
	void ParseDTD( decXmlDTD *dtd );
	/**
	 * Parses a markup declaration if one exists.
	 * @return true if a markup declaration has been parsed
	 */
	bool ParseMarkupDecl( decXmlDTD *dtd );
	/**
	 * Parses a element declaration if one exists.
	 * @return true if a element declaration has been parsed
	 */
	bool ParseElementDecl( decXmlDTD *dtd );
	/**
	 * Parses a declaration separator if one exists.
	 * @return true if a declaration separator has been parsed
	 */
	bool ParseDeclSep( decXmlDTD *dtd );
	/**
	 * Parses a mixed element declaration if one exists.
	 * @return true if a mixed element declaration has been parsed
	 */
	bool ParseElDeclMixed( decXmlElementDecl *elDecl );
	/** Parses a composed element declaration. */
	void ParseElDeclComposed( decXmlElementDecl *elDecl );
	/** Parses a declaration operator. */
	void ParseElDeclOp( decXmlElementDeclOp *op );
	/** Parses a declaration operator component. */
	void ParseElDeclOpCp( decXmlElementDeclOp *op );
	/**
	 * Parses an attribute list declaration if one exists.
	 * @return true if an attribute list declaration has been parsed
	 */
	bool ParseAttListDecl( decXmlDTD *dtd );
	/** Parses an attribute list declaration entry. */
	void ParseAttListDeclEntry( decXmlAttListDecl *alDecl );
	/** Parses an attribute list declaration enumeration. */
	void ParseAttListDeclEnum( decXmlAttListDeclEntry *entry );
	/*@}*/
};

// end of include only once
#endif
