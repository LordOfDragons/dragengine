/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlAttListDeclEntry.h"
#include "decXmlAttTypeEnum.h"
#include "decXmlAttValue.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlAttListDeclEntry
/////////////////////////////////

// constructor, destructor
decXmlAttListDeclEntry::decXmlAttListDeclEntry( const char *name ){
	pName = NULL;
	pAttType = eatCData;
	pDefType = edtImplied;
	pAttTypeEnum = NULL;
	pDefValue = NULL;
	try{
		SetName( name );
	}catch( const deException & ){
		if( pName ) delete [] pName;
		throw;
	}
}
decXmlAttListDeclEntry::~decXmlAttListDeclEntry(){
	if( pDefValue ) delete pDefValue;
	if( pAttTypeEnum ) delete pAttTypeEnum;
	if( pName ) delete [] pName;
}

// management
void decXmlAttListDeclEntry::SetName( const char *name ){
	if( ! name ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( name ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, name );
	if( pName ) delete [] pName;
	pName = newStr;
}
void decXmlAttListDeclEntry::SetAttributeType( eAttributeTypes attType ){
	if( attType < eatCData || attType >= EAT_COUNT ) DETHROW( deeInvalidParam );
	pAttType = attType;
}
void decXmlAttListDeclEntry::SetDefaultType( eDefaultTypes defType ){
	if( defType < edtRequired || defType >= EDT_COUNT ) DETHROW( deeInvalidParam );
	pDefType = defType;
}
void decXmlAttListDeclEntry::SetAttributeTypeEnum( decXmlAttTypeEnum *typeEnum ){
	if( pAttTypeEnum ){
		pAttTypeEnum->SetParent( NULL );
		delete pAttTypeEnum;
	}
	pAttTypeEnum = typeEnum;
	if( pAttTypeEnum ) pAttTypeEnum->SetParent( this );
}
void decXmlAttListDeclEntry::SetDefaultValue( decXmlAttValue *value ){
	if( pDefValue ){
		pDefValue->SetParent( NULL );
		delete pDefValue;
	}
	pDefValue = value;
	if( pDefValue ) pDefValue->SetParent( this );
}

// visiting
void decXmlAttListDeclEntry::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitAttListDeclEntry( this );
}

// casting
bool decXmlAttListDeclEntry::CanCastToAttListDeclEntry(){
	return true;
}
decXmlAttListDeclEntry *decXmlAttListDeclEntry::CastToAttListDeclEntry(){
	return this;
}
