/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <stdlib.h>
#include "decXmlContainer.h"
#include "decXmlElement.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlContainer
//////////////////////////

// constructor, destructor
decXmlContainer::decXmlContainer(){
	pElements = NULL;
	pElementCount = 0;
	pElementSize  = 0;
}
decXmlContainer::~decXmlContainer(){
	RemoveAllElements();
	if( pElements ) delete [] pElements;
}

// elements
int decXmlContainer::GetElementCount() const{
	return pElementCount;
}
bool decXmlContainer::IsEmpty() const{
	return pElementCount == 0;
}
decXmlElement *decXmlContainer::GetElementAt( int index ) const{
	if( index < 0 || index >= pElementCount ) DETHROW( deeInvalidParam );
	return pElements[ index ];
}
void decXmlContainer::AddElement( decXmlElement *element ){
	if( ! element ) DETHROW( deeInvalidParam );
	if( pElementCount == pElementSize ){
		int i, newSize = pElementSize * 3 / 2 + 1;
		decXmlElement **newArray = new decXmlElement*[ newSize ];
		if( ! newArray ) DETHROW( deeOutOfMemory );
		if( pElements ){
			for( i=0; i<pElementCount; i++ ) newArray[ i ] = pElements[ i ];
			delete [] pElements;
		}
		pElements = newArray;
		pElementSize = newSize;
	}
	pElements[ pElementCount ] = element;
	pElementCount++;
	element->SetParent( this );
}
void decXmlContainer::RemoveElement( decXmlElement *element ){
	int i, index = IndexOfElement( element );
	if( index == -1 ) DETHROW( deeInvalidParam );
	for( i=index; i<pElementCount-1; i++ ) pElements[ i ] = pElements[ i+1 ];
	pElementCount--;
	element->SetParent( NULL );
	delete element;
}
void decXmlContainer::RemoveAllElements(){
	while( pElementCount > 0 ){
		pElements[ pElementCount - 1 ]->SetParent( NULL );
		delete pElements[ pElementCount - 1 ];
		pElementCount--;
	}
}
int decXmlContainer::IndexOfElement( decXmlElement *element ){
	if( ! element ) return -1;
	int i;
	for( i=0; i<pElementCount; i++ ){
		if( pElements[ i ] == element ) return i;
	}
	return -1;
}
bool decXmlContainer::HasElement( decXmlElement *element ){
	if( ! element ) return false;
	int i;
	for( i=0; i<pElementCount; i++ ){
		if( pElements[ i ] == element ) return true;
	}
	return false;
}
void decXmlContainer::VisitElements( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	int i;
	for( i=0; i<pElementCount; i++ ) pElements[ i ]->Visit( visitor );
}

// visiting
void decXmlContainer::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitContainer( this );
}

// casting
bool decXmlContainer::CanCastToContainer(){
	return true;
}
decXmlContainer *decXmlContainer::CastToContainer(){
	return this;
}
