/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlAttValue.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlAttValue
////////////////////////////

// constructor, destructor
decXmlAttValue::decXmlAttValue( const char *name ){
	pName = NULL;
	pValue = NULL;
	pNamespace = NULL;
	pLocalName = NULL;
	try{
		SetName( name );
		pBreakUpName();
		pValue = new char[ 1 ];
		if( ! pValue ) DETHROW( deeOutOfMemory );
		pValue[ 0 ] = '\0';
	}catch( const deException & ){
		if( pLocalName ) delete [] pLocalName;
		if( pNamespace ) delete [] pNamespace;
		if( pValue ) delete [] pValue;
		if( pName ) delete [] pName;
		throw;
	}
}
decXmlAttValue::~decXmlAttValue(){
	if( pLocalName ) delete [] pLocalName;
	if( pNamespace ) delete [] pNamespace;
	if( pValue ) delete [] pValue;
	if( pName ) delete [] pName;
}

// management
void decXmlAttValue::SetName( const char *name ){
	if( ! name ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( name ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, name );
	if( pName ) delete [] pName;
	pName = newStr;
}
void decXmlAttValue::SetValue( const char *value ){
	if( ! value ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( value ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, value );
	if( pValue ) delete [] pValue;
	pValue = newStr;
}

// visiting
void decXmlAttValue::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitAttValue( this );
}

// casting
bool decXmlAttValue::CanCastToAttValue(){
	return true;
}
decXmlAttValue *decXmlAttValue::CastToAttValue(){
	return this;
}

// private functions
void decXmlAttValue::pBreakUpName(){
	char *newNS = NULL, *newLN = NULL;
	char *deli = strchr( pName, ':' );
	int offset = ( int )( deli - pName );
	try{
		if( deli ){
			newNS = new char[ offset + 1 ];
			if( ! newNS ) DETHROW( deeOutOfMemory );
			strncpy( newNS, pName, offset );
			newNS[ offset ] = '\0';
			newLN = new char[ strlen( deli ) ];
			if( ! newLN ) DETHROW( deeOutOfMemory );
			strcpy( newLN, deli + 1 );
		}else{
			newNS = new char[ 1 ];
			if( ! newNS ) DETHROW( deeOutOfMemory );
			newNS[ 0 ] = '\0';
			newLN = new char[ strlen( pName ) + 1 ];
			if( ! newLN ) DETHROW( deeOutOfMemory );
			strcpy( newLN, pName );
		}
		if( pNamespace ) delete [] pNamespace;
		pNamespace = newNS;
		newNS = NULL;
		if( pLocalName ) delete [] pLocalName;
		pLocalName = newLN;
		newLN = NULL;
	}catch( const deException & ){
		if( newNS ) delete [] newNS;
		if( newLN ) delete [] newLN;
		throw;
	}
}
