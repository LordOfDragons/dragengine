/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLELEMENT_H_
#define _DECXMLELEMENT_H_

// includes

// predefinitions
class decXmlVisitor;
class decXmlContainer;
class decXmlDocument;
class decXmlComment;
class decXmlPI;
class decXmlDTD;
class decXmlElementDecl;
class decXmlElementDeclEntry;
class decXmlElementDeclOp;
class decXmlAttListDecl;
class decXmlAttListDeclEntry;
class decXmlAttTypeEnum;
class decXmlAttTypeEnumEntry;
class decXmlElementTag;
class decXmlCharacterData;
class decXmlEntityReference;
class decXmlCharReference;
class decXmlCDSect;
class decXmlAttValue;
class decXmlNamespace;



/**
 * @brief Base XML Tree Element.
 *
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 */
class decXmlElement{
public:
	/** Occurance enumeration. */
	enum eOccuranceTypes{
		/** Element occures exactly one. */
		eotOnce,
		/** Element occures once or multiple times. */
		eotMultiple,
		/** Element occures a single time or never. */
		eotOptional,
		/** Element occures any amount of times. */
		eotAny,
		/** Dummy entry representing the number of occurent types. */
		EOT_COUNT
	};
private:
	int pLineNumber;
	int pPositionNumber;
	decXmlElement *pParent;
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/** Creates a new xml element. */
	decXmlElement();
	/** Cleans up the xml element. */
	virtual ~decXmlElement();
	/*@}*/
	
	/** @name Management */
	/*@{*/
	/**
	 * Retrieves the line number this element starts at in the source file.
	 * The line number is set by the parser for locating the error line.
	 * The line has to be 1 or larger with 1 beeing the first line.
	 */
	inline int GetLineNumber() const{ return pLineNumber; }
	/**
	 * Sets the line number this element starts at in the source file.
	 * The line number is set by the parser for locating the error line.
	 * The line has to be 1 or larger with 1 beeing the first line.
	 */
	void SetLineNumber( int lineNumber );
	/**
	 * Retrieves the position number this element starts at in the source file.
	 * The position number is set by the parser for locating the error position.
	 * The position has to be 0 or larger with 0 beeing the start of the line.
	 */
	inline int GetPositionNumber() const{ return pPositionNumber; }
	/**
	 * Sets the position number this element starts at in the source file.
	 * The position number is set by the parser for locating the error position.
	 * The position has to be 0 or larger with 0 beeing the start of the line.
	 */
	void SetPositionNumber( int positionNumber );
	/** Retrieves the parent of the node or NULL if it has none. */
	inline decXmlElement *GetParent() const{ return pParent; }
	/** Sets the parent of the node or removes it if NULL. */
	void SetParent( decXmlElement *parent );
	/*@}*/
	
	/** @name Visiting */
	/*@{*/
	/** Visits this node. */
	virtual void Visit( decXmlVisitor *visitor );
	/*@}*/
	
	/** @name Casting */
	/*@{*/
	/** Determines if this element can be cast to decXmlElement ( which is always true ). */
	virtual bool CanCastToElement();
	/** Determines if this element can be cast to decXmlContainer which is by default false. */
	virtual bool CanCastToContainer();
	/** Determines if this element can be cast to decXmlDocument which is by default false. */
	virtual bool CanCastToDocument();
	/** Determines if this element can be cast to decXmlComment which is by default false. */
	virtual bool CanCastToComment();
	/** Determines if this element can be cast to decXmlPI which is by default false. */
	virtual bool CanCastToPI();
	/** Determines if this element can be cast to decXmlDTD which is by default false. */
	virtual bool CanCastToDTD();
	/** Determines if this element can be cast to decXmlElementDecl which is by default false. */
	virtual bool CanCastToElementDecl();
	/** Determines if this element can be cast to decXmlElementDeclEntry which is by default false. */
	virtual bool CanCastToElementDeclEntry();
	/** Determines if this element can be cast to decXmlElementDeclOp which is by default false. */
	virtual bool CanCastToElementDeclOp();
	/** Determines if this element can be cast to decXmlAttListDecl which is by default false. */
	virtual bool CanCastToAttListDecl();
	/** Determines if this element can be cast to decXmlAttListDeclEntry which is by default false. */
	virtual bool CanCastToAttListDeclEntry();
	/** Determines if this element can be cast to decXmlAttTypeEnum which is by default false. */
	virtual bool CanCastToAttTypeEnum();
	/** Determines if this element can be cast to decXmlAttTypeEnumEntry which is by default false. */
	virtual bool CanCastToAttTypeEnumEntry();
	/** Determines if this element can be cast to decXmlElementTag which is by default false. */
	virtual bool CanCastToElementTag();
	/** Determines if this element can be cast to decXmlCharacterData which is by default false. */
	virtual bool CanCastToCharacterData();
	/** Determines if this element can be cast to decXmlEntityReference which is by default false. */
	virtual bool CanCastToEntityReference();
	/** Determines if this element can be cast to decXmlCharReference which is by default false. */
	virtual bool CanCastToCharReference();
	/** Determines if this element can be cast to decXmlCDSect which is by default false. */
	virtual bool CanCastToCDSect();
	/** Determines if this element can be cast to decXmlAttValue which is by default false. */
	virtual bool CanCastToAttValue();
	/** Determines if this element can be cast to decXmlNamespace which is by default false. */
	virtual bool CanCastToNamespace();
	/** Safely casts this element to decXmlElement or throwns an exception otherwise. */
	virtual decXmlElement *CastToElement();
	/** Safely casts this element to decXmlContainer or throwns an exception otherwise. */
	virtual decXmlContainer *CastToContainer();
	/** Safely casts this element to decXmlDocument or throwns an exception otherwise. */
	virtual decXmlDocument *CastToDocument();
	/** Safely casts this element to decXmlComment or throwns an exception otherwise. */
	virtual decXmlComment *CastToComment();
	/** Safely casts this element to decXmlPI or throwns an exception otherwise. */
	virtual decXmlPI *CastToPI();
	/** Safely casts this element to decXmlDTD or throwns an exception otherwise. */
	virtual decXmlDTD *CastToDTD();
	/** Safely casts this element to decXmlElementDecl or throwns an exception otherwise. */
	virtual decXmlElementDecl *CastToElementDecl();
	/** Safely casts this element to decXmlElementDeclEntry or throwns an exception otherwise. */
	virtual decXmlElementDeclEntry *CastToElementDeclEntry();
	/** Safely casts this element to decXmlElementDeclOp or throwns an exception otherwise. */
	virtual decXmlElementDeclOp *CastToElementDeclOp();
	/** Safely casts this element to decXmlAttListDecl or throwns an exception otherwise. */
	virtual decXmlAttListDecl *CastToAttListDecl();
	/** Safely casts this element to decXmlAttListDeclEntry or throwns an exception otherwise. */
	virtual decXmlAttListDeclEntry *CastToAttListDeclEntry();
	/** Safely casts this element to decXmlAttTypeEnum or throwns an exception otherwise. */
	virtual decXmlAttTypeEnum *CastToAttTypeEnum();
	/** Safely casts this element to decXmlAttTypeEnumEntry or throwns an exception otherwise. */
	virtual decXmlAttTypeEnumEntry *CastToAttTypeEnumEntry();
	/** Safely casts this element to decXmlElementTag or throwns an exception otherwise. */
	virtual decXmlElementTag *CastToElementTag();
	/** Safely casts this element to decXmlCharacterData or throwns an exception otherwise. */
	virtual decXmlCharacterData *CastToCharacterData();
	/** Safely casts this element to decXmlEntityReference or throwns an exception otherwise. */
	virtual decXmlEntityReference *CastToEntityReference();
	/** Safely casts this element to decXmlCharReference or throwns an exception otherwise. */
	virtual decXmlCharReference *CastToCharReference();
	/** Safely casts this element to decXmlCDSect or throwns an exception otherwise. */
	virtual decXmlCDSect *CastToCDSect();
	/** Safely casts this element to decXmlAttValue or throwns an exception otherwise. */
	virtual decXmlAttValue *CastToAttValue();
	/** Safely casts this element to decXmlNamespace or throwns an exception otherwise. */
	virtual decXmlNamespace *CastToNamespace();
	/*@}*/
};

// end of include only once
#endif
