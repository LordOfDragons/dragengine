/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlAttListDecl.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlAttListDecl
////////////////////////////

// constructor, destructor
decXmlAttListDecl::decXmlAttListDecl( const char *name ){
	pName = NULL;
	try{
		SetName( name );
	}catch( const deException & ){
		if( pName ) delete [] pName;
		throw;
	}
}
decXmlAttListDecl::~decXmlAttListDecl(){
	if( pName ) delete [] pName;
}

// management
void decXmlAttListDecl::SetName( const char *name ){
	if( ! name ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( name ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, name );
	if( pName ) delete [] pName;
	pName = newStr;
}

// visiting
void decXmlAttListDecl::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitAttListDecl( this );
}

// casting
bool decXmlAttListDecl::CanCastToAttListDecl(){
	return true;
}
decXmlAttListDecl *decXmlAttListDecl::CastToAttListDecl(){
	return this;
}
