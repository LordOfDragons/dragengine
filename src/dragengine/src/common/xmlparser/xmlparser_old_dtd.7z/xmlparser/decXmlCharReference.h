/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLCHARREFERENCE_H_
#define _DECXMLCHARREFERENCE_H_

// includes
#include "decXmlElement.h"

// predefinitions


/**
 * @brief XML Character Reference.
 *
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 */
class decXmlCharReference : public decXmlElement{
public:
	/** Radix enumeration. */
	enum eRadices{
		/** Decimal radix. */
		erDecimal,
		/** Hexadecimal radix. */
		erHexadecimal
	};
private:
	char *pData;
	eRadices pRadix;
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/**
	 * Creates a new xml character reference wwith the given data and radix.
	 * @param data Character Data
	 * @param radix Value from eRadices
	 */
	decXmlCharReference( const char *data, eRadices radix );
	/** Cleans up the xml character data. */
	~decXmlCharReference();
	/*@}*/
	
	/** @name Management */
	/*@{*/
	inline const char *GetData() const{ return (const char *)pData; }
	inline eRadices GetRadix() const{ return pRadix; }
	inline bool IsDecimal() const{ return pRadix == erDecimal; }
	inline bool IsHexadecimal() const{ return pRadix == erHexadecimal; }
	void SetData( const char *data );
	void SetRadix( eRadices radix );
	/*@}*/
	
	/** @name Visiting */
	void Visit( decXmlVisitor *visitor );
	/*@}*/
	
	/** @name Casting */
	/*@{*/
	virtual bool CanCastToCharReference();
	virtual decXmlCharReference *CastToCharReference();
	/*@}*/
};

// end of include only once
#endif
