/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlElementTag.h"
#include "decXmlAttValue.h"
#include "decXmlCDSect.h"
#include "decXmlCharacterData.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlElementTag
////////////////////////

// constructor, destructor
decXmlElementTag::decXmlElementTag( const char *name ){
	pName = NULL;
	pNamespace = NULL;
	pLocalName = NULL;
	try{
		SetName( name );
		pBreakUpName();
	}catch( const deException & ){
		if( pLocalName ) delete [] pLocalName;
		if( pNamespace ) delete [] pNamespace;
		if( pName ) delete [] pName;
		throw;
	}
}
decXmlElementTag::~decXmlElementTag(){
	if( pLocalName ) delete [] pLocalName;
	if( pNamespace ) delete [] pNamespace;
	if( pName ) delete [] pName;
}

// management
void decXmlElementTag::SetName( const char *name ){
	if( ! name ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( name ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, name );
	if( pName ) delete [] pName;
	pName = newStr;
}

// helper functions
decXmlCharacterData *decXmlElementTag::GetFirstData() const{
	int i;
	for( i=0; i<GetElementCount(); i++ ){
		if( GetElementAt( i )->CanCastToCharacterData() ){
			return GetElementAt( i )->CastToCharacterData();
			
		}else if( GetElementAt( i )->CanCastToCDSect() ){
			return GetElementAt( i )->CastToCDSect();
		}
	}
	return NULL;
}
decXmlElementTag *decXmlElementTag::GetElementIfTag( int index ) const{
	decXmlElement *element = GetElementAt( index );
	if( element->CanCastToElementTag() ){
		return element->CastToElementTag();
	}else{
		return NULL;
	}
}
decXmlAttValue *decXmlElementTag::FindAttribute( const char *name ) const{
	decXmlAttValue *value;
	decXmlElement *element;
	int i, count = GetElementCount();
	for( i=0; i<count; i++ ){
		element = GetElementAt( i );
		if( element->CanCastToAttValue() ){
			value = element->CastToAttValue();
			if( strcmp( value->GetName(), name ) == 0 ){
				return value;
			}
		}
	}
	return NULL;
}

// visiting
void decXmlElementTag::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitElementTag( this );
}

// casting
bool decXmlElementTag::CanCastToElementTag(){
	return true;
}
decXmlElementTag *decXmlElementTag::CastToElementTag(){
	return this;
}

// private functions
void decXmlElementTag::pBreakUpName(){
	char *newNS = NULL, *newLN = NULL;
	char *deli = strchr( pName, ':' );
	int offset = ( int )( deli - pName );
	try{
		if( deli ){
			newNS = new char[ offset + 1 ];
			if( ! newNS ) DETHROW( deeOutOfMemory );
			strncpy( newNS, pName, offset );
			newNS[ offset ] = '\0';
			newLN = new char[ strlen( deli ) ];
			if( ! newLN ) DETHROW( deeOutOfMemory );
			strcpy( newLN, deli + 1 );
		}else{
			newNS = new char[ 1 ];
			if( ! newNS ) DETHROW( deeOutOfMemory );
			newNS[ 0 ] = '\0';
			newLN = new char[ strlen( pName ) + 1 ];
			if( ! newLN ) DETHROW( deeOutOfMemory );
			strcpy( newLN, pName );
		}
		if( pNamespace ) delete [] pNamespace;
		pNamespace = newNS;
		newNS = NULL;
		if( pLocalName ) delete [] pLocalName;
		pLocalName = newLN;
		newLN = NULL;
	}catch( const deException & ){
		if( newNS ) delete [] newNS;
		if( newLN ) delete [] newLN;
		throw;
	}
}
