/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLATTVALUE_H_
#define _DECXMLATTVALUE_H_

// includes
#include "decXmlElement.h"


// predefinitions


/**
 * @brief XML Attribute Value.
 *
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 */
class decXmlAttValue : public decXmlElement{
private:
	char *pName, *pValue, *pNamespace, *pLocalName;
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/** Creates a new xml attribute value. */
	decXmlAttValue( const char *name );
	/** Cleans up the xml attribute value. */
	~decXmlAttValue();
	/*@}*/
	
	/** @name Management */
	/*@{*/
	inline const char *GetName() const{ return (const char *)pName; }
	void SetName( const char *name );
	inline const char *GetValue() const{ return (const char *)pValue; }
	void SetValue( const char *value );
	/** Retrieves the namespace part of the name. */
	inline const char *GetNamespace() const{ return (const char *)pNamespace; }
	/** Retrieves the local name part of the name. */
	inline const char *GetLocalName() const{ return (const char *)pLocalName; }
	/*@}*/
	
	/** @name Visiting */
	/*@{*/
	void Visit( decXmlVisitor *visitor );
	/*@}*/
	
	/** @name Casting */
	/*@{*/
	virtual bool CanCastToAttValue();
	virtual decXmlAttValue *CastToAttValue();
	/*@}*/
private:
	void pBreakUpName();
};

// end of include only once
#endif
