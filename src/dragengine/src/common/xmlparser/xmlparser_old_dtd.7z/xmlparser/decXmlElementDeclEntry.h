/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLELEMENTDECLENTRY_H_
#define _DECXMLELEMENTDECLENTRY_H_

// includes
#include "decXmlElement.h"


// predefinitions


/**
 * @brief XML Element Declaration Entry.
 *
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 */
class decXmlElementDeclEntry : public decXmlElement{
private:
	char *pName;
	eOccuranceTypes pOccuranceType;
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/** Creates a new xml element declaration entry. */
	decXmlElementDeclEntry( const char *name );
	/** Cleans up the xml element declaration entry. */
	~decXmlElementDeclEntry();
	/*@}*/
	
	/** @name Management */
	/*@{*/
	inline const char *GetName() const{ return (const char *)pName; }
	void SetName( const char *name );
	inline eOccuranceTypes GetOccuranceType() const{ return pOccuranceType; }
	void SetOccuranceType( eOccuranceTypes occuranceType );
	/*@}*/
	
	/** @name Visiting */
	/*@{*/
	void Visit( decXmlVisitor *visitor );
	/*@}*/
	
	/** @name Casting */
	/*@{*/
	virtual bool CanCastToElementDeclEntry();
	virtual decXmlElementDeclEntry *CastToElementDeclEntry();
	/*@}*/
private:
};

// end of include only once
#endif
