/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlDocument.h"
#include "decXmlVisitor.h"
#include "visitors/decXmlVisitorCleanCharData.h"
#include "visitors/decXmlVisitorStripComments.h"
#include "../exceptions.h"



// class decXmlDocument
/////////////////////////

// constructor, destructor
decXmlDocument::decXmlDocument(){
	pEncoding = NULL;
	pDocType = NULL;
	pSysLit = NULL;
	pPubLit = NULL;
	pStandalone = false;
	try{
		pEncoding = new char[ 1 ];
		if( ! pEncoding ) DETHROW( deeOutOfMemory );
		pEncoding[ 0 ] = '\0';
		pDocType = new char[ 1 ];
		if( ! pDocType ) DETHROW( deeOutOfMemory );
		pDocType[ 0 ] = '\0';
		pSysLit = new char[ 1 ];
		if( ! pSysLit ) DETHROW( deeOutOfMemory );
		pSysLit[ 0 ] = '\0';
		pPubLit = new char[ 1 ];
		if( ! pPubLit ) DETHROW( deeOutOfMemory );
		pPubLit[ 0 ] = '\0';
	}catch( const deException & ){
		if( pPubLit ) delete [] pPubLit;
		if( pSysLit ) delete [] pSysLit;
		if( pDocType ) delete [] pDocType;
		if( pEncoding ) delete [] pEncoding;
		throw;
	}
}
decXmlDocument::~decXmlDocument(){
	if( pPubLit ) delete [] pPubLit;
	if( pSysLit ) delete [] pSysLit;
	if( pDocType ) delete [] pDocType;
	if( pEncoding ) delete [] pEncoding;
}

// management
void decXmlDocument::SetEncoding( const char *encoding ){
	if( ! encoding ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( encoding ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, encoding );
	if( pEncoding ) delete [] pEncoding;
	pEncoding = newStr;
}
void decXmlDocument::SetDocType( const char *docType ){
	if( ! docType ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( docType ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, docType );
	if( pDocType ) delete [] pDocType;
	pDocType = newStr;
}
void decXmlDocument::SetSystemLiteral( const char *sysLit ){
	if( ! sysLit ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( sysLit ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, sysLit );
	if( pSysLit ) delete [] pSysLit;
	pSysLit = newStr;
}
void decXmlDocument::SetPublicLiteral( const char *pubLit ){
	if( ! pubLit ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( pubLit ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, pubLit );
	if( pPubLit ) delete [] pPubLit;
	pPubLit = newStr;
}
void decXmlDocument::SetStandalone( bool standalone ){
	pStandalone = standalone;
}
decXmlElementTag *decXmlDocument::GetRoot() const{
	decXmlElement *element;
	int i;
	for( i=0; i<GetElementCount(); i++ ){
		element = GetElementAt( i );
		if( element->CanCastToElementTag() ) return element->CastToElementTag();
	}
	return NULL;
}

// visiting
void decXmlDocument::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitDocument( this );
}

// predefined visitors
void decXmlDocument::CleanCharData(){
	decXmlVisitorCleanCharData visitor;
	Visit( &visitor );
}
void decXmlDocument::StripComments(){
	decXmlVisitorStripComments visitor;
	Visit( &visitor );
}

// casting
bool decXmlDocument::CanCastToDocument(){
	return true;
}
decXmlDocument *decXmlDocument::CastToDocument(){
	return this;
}
