/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlComment.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlComment
////////////////////////

// constructor, destructor
decXmlComment::decXmlComment( const char *comment ){
	pComment = NULL;
	try{
		SetComment( comment );
	}catch( const deException & ){
		if( pComment ) delete [] pComment;
		throw;
	}
}
decXmlComment::~decXmlComment(){
	if( pComment ) delete [] pComment;
}

// management
void decXmlComment::SetComment( const char *comment ){
	if( ! comment ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( comment ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, comment );
	if( pComment ) delete [] pComment;
	pComment = newStr;
}

// visiting
void decXmlComment::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitComment( this );
}

// casting
bool decXmlComment::CanCastToComment(){
	return true;
}
decXmlComment *decXmlComment::CastToComment(){
	return this;
}
