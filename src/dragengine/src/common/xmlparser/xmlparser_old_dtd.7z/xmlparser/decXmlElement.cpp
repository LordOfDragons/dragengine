/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <stdlib.h>
#include "decXmlElement.h"
#include "decXmlVisitor.h"
#include "decXmlContainer.h"
#include "decXmlDocument.h"
#include "decXmlComment.h"
#include "decXmlPI.h"
#include "decXmlDTD.h"
#include "decXmlElementDecl.h"
#include "decXmlElementDeclEntry.h"
#include "decXmlElementDeclOp.h"
#include "decXmlAttListDecl.h"
#include "decXmlAttListDeclEntry.h"
#include "decXmlAttTypeEnum.h"
#include "decXmlAttTypeEnumEntry.h"
#include "decXmlElementTag.h"
#include "decXmlCharacterData.h"
#include "decXmlEntityReference.h"
#include "decXmlCharReference.h"
#include "decXmlCDSect.h"
#include "decXmlAttValue.h"
#include "decXmlNamespace.h"
#include "../exceptions.h"



// class decXmlElement
////////////////////////

// constructor, destructor
decXmlElement::decXmlElement(){
	pLineNumber = 1;
	pPositionNumber = 0;
	pParent = NULL;
}
decXmlElement::~decXmlElement(){
}

// management
void decXmlElement::SetLineNumber( int lineNumber ){
	if( lineNumber < 1 ) DETHROW( deeInvalidParam );
	pLineNumber = lineNumber;
}
void decXmlElement::SetPositionNumber( int positionNumber ){
	if( positionNumber < 1 ) DETHROW( deeInvalidParam );
	pPositionNumber = positionNumber;
}
void decXmlElement::SetParent( decXmlElement *parent ){
	pParent = parent;
}

// visiting
void decXmlElement::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitElement( this );
}

// casting
bool decXmlElement::CanCastToElement(){
	return true;
}
bool decXmlElement::CanCastToContainer(){
	return false;
}
bool decXmlElement::CanCastToDocument(){
	return false;
}
bool decXmlElement::CanCastToComment(){
	return false;
}
bool decXmlElement::CanCastToPI(){
	return false;
}
bool decXmlElement::CanCastToDTD(){
	return false;
}
bool decXmlElement::CanCastToElementDecl(){
	return false;
}
bool decXmlElement::CanCastToElementDeclEntry(){
	return false;
}
bool decXmlElement::CanCastToElementDeclOp(){
	return false;
}
bool decXmlElement::CanCastToAttListDecl(){
	return false;
}
bool decXmlElement::CanCastToAttListDeclEntry(){
	return false;
}
bool decXmlElement::CanCastToAttTypeEnum(){
	return false;
}
bool decXmlElement::CanCastToAttTypeEnumEntry(){
	return false;
}
bool decXmlElement::CanCastToElementTag(){
	return false;
}
bool decXmlElement::CanCastToCharacterData(){
	return false;
}
bool decXmlElement::CanCastToEntityReference(){
	return false;
}
bool decXmlElement::CanCastToCharReference(){
	return false;
}
bool decXmlElement::CanCastToCDSect(){
	return false;
}
bool decXmlElement::CanCastToAttValue(){
	return false;
}
bool decXmlElement::CanCastToNamespace(){
	return false;
}

decXmlElement *decXmlElement::CastToElement(){
	return this;
}
decXmlContainer *decXmlElement::CastToContainer(){
	DETHROW( deeInvalidParam );
}
decXmlDocument *decXmlElement::CastToDocument(){
	DETHROW( deeInvalidParam );
}
decXmlComment *decXmlElement::CastToComment(){
	DETHROW( deeInvalidParam );
}
decXmlPI *decXmlElement::CastToPI(){
	DETHROW( deeInvalidParam );
}
decXmlDTD *decXmlElement::CastToDTD(){
	DETHROW( deeInvalidParam );
}
decXmlElementDecl *decXmlElement::CastToElementDecl(){
	DETHROW( deeInvalidParam );
}
decXmlElementDeclEntry *decXmlElement::CastToElementDeclEntry(){
	DETHROW( deeInvalidParam );
}
decXmlElementDeclOp *decXmlElement::CastToElementDeclOp(){
	DETHROW( deeInvalidParam );
}
decXmlAttListDecl *decXmlElement::CastToAttListDecl(){
	DETHROW( deeInvalidParam );
}
decXmlAttListDeclEntry *decXmlElement::CastToAttListDeclEntry(){
	DETHROW( deeInvalidParam );
}
decXmlAttTypeEnum *decXmlElement::CastToAttTypeEnum(){
	DETHROW( deeInvalidParam );
}
decXmlAttTypeEnumEntry *decXmlElement::CastToAttTypeEnumEntry(){
	DETHROW( deeInvalidParam );
}
decXmlElementTag *decXmlElement::CastToElementTag(){
	DETHROW( deeInvalidParam );
}
decXmlCharacterData *decXmlElement::CastToCharacterData(){
	DETHROW( deeInvalidParam );
}
decXmlEntityReference *decXmlElement::CastToEntityReference(){
	DETHROW( deeInvalidParam );
}
decXmlCharReference *decXmlElement::CastToCharReference(){
	DETHROW( deeInvalidParam );
}
decXmlCDSect *decXmlElement::CastToCDSect(){
	DETHROW( deeInvalidParam );
}
decXmlAttValue *decXmlElement::CastToAttValue(){
	DETHROW( deeInvalidParam );
}
decXmlNamespace *decXmlElement::CastToNamespace(){
	DETHROW( deeInvalidParam );
}
