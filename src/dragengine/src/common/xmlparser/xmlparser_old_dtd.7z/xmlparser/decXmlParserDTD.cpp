/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlDTD.h"
#include "decXmlContainer.h"
#include "decXmlElement.h"
#include "decXmlElementDecl.h"
#include "decXmlElementDeclEntry.h"
#include "decXmlElementDeclOp.h"
#include "decXmlAttListDecl.h"
#include "decXmlAttListDeclEntry.h"
#include "decXmlAttTypeEnum.h"
#include "decXmlAttTypeEnumEntry.h"
#include "decXmlAttValue.h"
#include "decXmlParserDTD.h"
#include "decXmlParser.h"
#include "../file/decBaseFileReader.h"
#include "../exceptions.h"


// class decXmlParserDTD
/////////////////////////

// constructor, destructor
decXmlParserDTD::decXmlParserDTD( decXmlParser *parent ){
	if( ! parent ) DETHROW( deeInvalidParam );
	pParent = parent;
}
decXmlParserDTD::~decXmlParserDTD(){
}

// parsing tokens
void decXmlParserDTD::ParseDTD( decXmlDTD *dtd ){
	if( ! dtd ) DETHROW( deeInvalidParam );
	// intSubset ::= (markupdecl | DeclSep)*
	while( ParseMarkupDecl( dtd ) || ParseDeclSep( dtd ) );
}
bool decXmlParserDTD::ParseMarkupDecl( decXmlDTD *dtd ){
	// markupdecl ::= elementdecl | AttlistDecl | EntityDecl | NotationDecl | PI | Comment
	return ParseElementDecl( dtd ) || ParseAttListDecl( dtd )
		|| pParent->ParsePI( dtd ) || pParent->ParseComment( dtd );
}
bool decXmlParserDTD::ParseElementDecl( decXmlDTD *dtd ){
	decXmlElementDecl *elDecl = NULL;
	int lineNumber = pParent->GetTokenLineNumber();
	int posNumber = pParent->GetTokenPositionNumber();
	// elementdecl ::= '<!ELEMENT' S Name S contentspec S? '>'
	if( ! pParent->ParseToken( "<!ELEMENT" ) ) return false;
	if( pParent->ParseSpaces() == 0 ) pParent->RaiseFatalError();
	pParent->ParseName( 0, true );
	elDecl = new decXmlElementDecl( pParent->GetCleanString() );
	if( ! elDecl ) DETHROW( deeOutOfMemory );
	elDecl->SetLineNumber( lineNumber );
	elDecl->SetPositionNumber( posNumber );
	try{
		if( pParent->ParseSpaces() == 0 ) pParent->RaiseFatalError();
		// contentspec ::= 'EMPTY' | 'ANY' | Mixed | children
		if( pParent->ParseToken( "EMPTY" ) ){
			elDecl->SetContentType( decXmlElementDecl::ectEmpty );
		}else if( pParent->ParseToken( "ANY" ) ){
			elDecl->SetContentType( decXmlElementDecl::ectAny );
		}else if( pParent->ParseToken( "(" ) ){
			pParent->ParseSpaces();
			if( ! ParseElDeclMixed( elDecl ) ){
				ParseElDeclComposed( elDecl );
			}
		}else{
			pParent->RaiseFatalError();
		}
		pParent->ParseSpaces();
		if( ! pParent->ParseToken( ">" ) ) pParent->RaiseFatalError();
		dtd->AddElement( elDecl );
	}catch( const deException & ){
		delete elDecl;
		throw;
	}
	return true;
}
bool decXmlParserDTD::ParseDeclSep( decXmlDTD *dtd ){
	// DeclSep ::= PEReference | S
	// PEReference ::= '%' Name ';'
	if( pParent->ParseToken( "%" ) ){
		pParent->ParseName( 0, true );
		if( ! pParent->ParseToken( ";" ) ) pParent->RaiseFatalError();
	}else{
		if( pParent->ParseSpaces() == 0 ) return false;
	}
	return true;
}
bool decXmlParserDTD::ParseElDeclMixed( decXmlElementDecl *elDecl ){
	decXmlElementDeclEntry *entry = NULL;
	const char *endToken = ")";
	int lineNumber = pParent->GetTokenLineNumber();
	int posNumber = pParent->GetTokenPositionNumber();
	// Mixed ::= '(' S? '#PCDATA' (S? '|' S? Name)* S? ')*' | '(' S? '#PCDATA' S? ')'
	if( ! pParent->ParseToken( "#PCDATA" ) ) return false;
		elDecl->SetContentType( decXmlElementDecl::ectMixed );
	pParent->ParseSpaces();
	while( pParent->ParseToken( "|" ) ){
		pParent->ParseSpaces();
		pParent->ParseName( 0, true );
		entry = new decXmlElementDeclEntry( pParent->GetCleanString() );
		if( ! entry ) DETHROW( deeOutOfMemory );
		entry->SetLineNumber( lineNumber );
		entry->SetPositionNumber( posNumber );
		try{
			entry->SetOccuranceType( decXmlElement::eotAny );
			elDecl->AddElement( entry );
			entry = NULL;
		}catch( const deException & ){
			delete entry;
			throw;
		}
		pParent->ParseSpaces();
		endToken = ")*";
	}
	if( ! pParent->ParseToken( endToken ) ) pParent->RaiseFatalError();
	return true;
}
void decXmlParserDTD::ParseElDeclComposed( decXmlElementDecl *elDecl ){
	decXmlElementDeclOp *op = NULL;
	int lineNumber = pParent->GetTokenLineNumber();
	int posNumber = pParent->GetTokenPositionNumber();
	op = new decXmlElementDeclOp;
	if( ! op ) DETHROW( deeOutOfMemory );
	op->SetLineNumber( lineNumber );
	op->SetPositionNumber( posNumber );
	try{
		elDecl->SetContentType( decXmlElementDecl::ectComposed );
		ParseElDeclOp( op );
		elDecl->AddElement( op );
	}catch( const deException & ){
		delete op;
		throw;
	}
}
void decXmlParserDTD::ParseElDeclOp( decXmlElementDeclOp *op ){
	const char *delimiter;
	// children ::= (choice | seq) ('?' | '*' | '+')?
	// cp ::= (Name | choice | seq) ('?' | '*' | '+')?
	// choice ::= '(' S? cp ( S? '|' S? cp )+ S? ')'
	// seq ::= '(' S? cp ( S? ',' S? cp )* S? ')'
	ParseElDeclOpCp( op );
	pParent->ParseSpaces();
	if( pParent->ParseToken( "|" ) ){
		delimiter = "|";
		op->SetOperator( decXmlElementDeclOp::eopOr );
	}else if ( pParent->ParseToken( "," ) ){
		delimiter = ",";
		op->SetOperator( decXmlElementDeclOp::eopSeq );
	}else{
		pParent->RaiseFatalError();
		return;
	}
	while( true ){
		ParseElDeclOpCp( op );
		pParent->ParseSpaces();
		if( ! pParent->ParseToken( delimiter ) ) break;
	}
	if( ! pParent->ParseToken( ")" ) ) pParent->RaiseFatalError();
	if( pParent->ParseToken( "?" ) ){
		op->SetOccuranceType( decXmlElement::eotOptional );
	}else if( pParent->ParseToken( "*" ) ){
		op->SetOccuranceType( decXmlElement::eotAny );
	}else if( pParent->ParseToken( "+" ) ){
		op->SetOccuranceType( decXmlElement::eotMultiple );
	}else{
		op->SetOccuranceType( decXmlElement::eotOnce );
	}
}
void decXmlParserDTD::ParseElDeclOpCp( decXmlElementDeclOp *op ){
	decXmlElementDeclOp *subOp = NULL;
	decXmlElementDeclEntry *entry = NULL;
	int lineNumber = pParent->GetTokenLineNumber();
	int posNumber = pParent->GetTokenPositionNumber();
	// cp ::= (Name | choice | seq) ('?' | '*' | '+')?
	pParent->ParseSpaces();
	if( pParent->ParseToken( "(" ) ){
		subOp = new decXmlElementDeclOp;
		if( ! subOp ) DETHROW( deeOutOfMemory );
		subOp->SetLineNumber( lineNumber );
		subOp->SetPositionNumber( posNumber );
		try{
			pParent->ParseSpaces();
			ParseElDeclOp( subOp );
			op->AddElement( subOp );
		}catch( const deException & ){
			delete subOp;
			throw;
		}
	}else{
		pParent->ParseName( 0, true );
		entry = new decXmlElementDeclEntry( pParent->GetCleanString() );
		if( ! entry ) DETHROW( deeOutOfMemory );
		entry->SetLineNumber( lineNumber );
		entry->SetPositionNumber( posNumber );
		try{
			if( pParent->ParseToken( "?" ) ){
				entry->SetOccuranceType( decXmlElement::eotOptional );
			}else if( pParent->ParseToken( "*" ) ){
				entry->SetOccuranceType( decXmlElement::eotAny );
			}else if( pParent->ParseToken( "+" ) ){
				entry->SetOccuranceType( decXmlElement::eotMultiple );
			}else{
				entry->SetOccuranceType( decXmlElement::eotOnce );
			}
			op->AddElement( entry );
			entry = NULL;
		}catch( const deException & ){
			delete entry;
			throw;
		}
	}
}
bool decXmlParserDTD::ParseAttListDecl( decXmlDTD *dtd ){
	decXmlAttListDecl *alDecl = NULL;
	bool hasSpaces;
	int lineNumber = pParent->GetTokenLineNumber();
	int posNumber = pParent->GetTokenPositionNumber();
	// AttlistDecl ::= '<!ATTLIST' S Name AttDef* S? '>'
	if( ! pParent->ParseToken( "<!ATTLIST" ) ) return false;
	if( pParent->ParseSpaces() == 0 ) pParent->RaiseFatalError();
	pParent->ParseName( 0, true );
	alDecl = new decXmlAttListDecl( pParent->GetCleanString() );
	if( ! alDecl ) DETHROW( deeOutOfMemory );
	alDecl->SetLineNumber( lineNumber );
	alDecl->SetPositionNumber( posNumber );
	try{
		// AttDef ::= S Name S AttType S DefaultDecl
		// AttType ::= StringType | TokenizedType | EnumeratedType
		// StringType ::= 'CDATA'
		// TokenizedType ::= 'ID' | 'IDREF' | 'IDREFS' | 'ENTITY' | 'ENTITIES' | 'NMTOKEN' | 'NMTOKENS'
		//
		while( true ){
			hasSpaces = pParent->ParseSpaces() > 0;
			if( pParent->ParseToken( ">" ) ) break;
			if( ! hasSpaces ) pParent->RaiseFatalError();
			ParseAttListDeclEntry( alDecl );
		}
		dtd->AddElement( alDecl );
	}catch( const deException & ){
		delete alDecl;
		throw;
	}
	return true;
}
void decXmlParserDTD::ParseAttListDeclEntry( decXmlAttListDecl *alDecl ){
	decXmlAttListDeclEntry *entry = NULL;
	decXmlAttValue *attValue = NULL;
	int lineNumber = pParent->GetTokenLineNumber();
	int posNumber = pParent->GetTokenPositionNumber();
	// AttDef ::= S Name S AttType S DefaultDecl
	pParent->ParseName( 0, true );
	entry = new decXmlAttListDeclEntry( pParent->GetCleanString() );
	if( ! entry ) DETHROW( deeOutOfMemory );
	entry->SetLineNumber( lineNumber );
	entry->SetPositionNumber( posNumber );
	try{
		// AttType ::= StringType | TokenizedType | EnumeratedType
		// StringType ::= 'CDATA'
		// TokenizedType ::= 'ID' | 'IDREF' | 'IDREFS' | 'ENTITY' | 'ENTITIES' | 'NMTOKEN' | 'NMTOKENS'
		if( pParent->ParseSpaces() == 0 ) pParent->RaiseFatalError();
		if( pParent->ParseToken( "CDATA" ) ){
			entry->SetAttributeType( decXmlAttListDeclEntry::eatCData );
		}else if( pParent->ParseToken( "ID" ) ){
			entry->SetAttributeType( decXmlAttListDeclEntry::eatID );
		}else if( pParent->ParseToken( "IDREF" ) ){
			entry->SetAttributeType( decXmlAttListDeclEntry::eatIDRef );
		}else if( pParent->ParseToken( "IDREFS" ) ){
			entry->SetAttributeType( decXmlAttListDeclEntry::eatIDRefs );
		}else if( pParent->ParseToken( "ENTITY" ) ){
			entry->SetAttributeType( decXmlAttListDeclEntry::eatEntity );
		}else if( pParent->ParseToken( "ENTITIES" ) ){
			entry->SetAttributeType( decXmlAttListDeclEntry::eatEntities );
		}else if( pParent->ParseToken( "NMTOKEN" ) ){
			entry->SetAttributeType( decXmlAttListDeclEntry::eatNMToken );
		}else if( pParent->ParseToken( "NMTOKENS" ) ){
			entry->SetAttributeType( decXmlAttListDeclEntry::eatNMTokens );
		}else{
			entry->SetAttributeType( decXmlAttListDeclEntry::eatEnum );
			ParseAttListDeclEnum( entry );
		}
		// DefaultDecl ::= '#REQUIRED' | '#IMPLIED' | (('#FIXED' S)? AttValue)
		lineNumber = pParent->GetTokenLineNumber();
		posNumber = pParent->GetTokenPositionNumber();
		if( pParent->ParseSpaces() == 0 ) pParent->RaiseFatalError();
		if( pParent->ParseToken( "#REQUIRED" ) ){
			entry->SetDefaultType( decXmlAttListDeclEntry::edtRequired );
		}else if( pParent->ParseToken( "#IMPLIED" ) ){
			entry->SetDefaultType( decXmlAttListDeclEntry::edtImplied );
		}else{
			if( pParent->ParseToken( "#FIXED" ) ){
				entry->SetDefaultType( decXmlAttListDeclEntry::edtFixed );
				if( pParent->ParseSpaces() == 0 ) pParent->RaiseFatalError();
			}else{
				entry->SetDefaultType( decXmlAttListDeclEntry::edtAny );
			}
			attValue = new decXmlAttValue( "" );
			if( ! attValue ) DETHROW( deeOutOfMemory );
			attValue->SetLineNumber( lineNumber );
			attValue->SetPositionNumber( posNumber );
			pParent->ParseAttValue( attValue );
			entry->SetDefaultValue( attValue );
			attValue = NULL;
		}
		// add to decl
		alDecl->AddElement( entry );
	}catch( const deException & ){
		if( attValue ) delete attValue;
		delete entry;
		throw;
	}
}
void decXmlParserDTD::ParseAttListDeclEnum( decXmlAttListDeclEntry *entry ){
	decXmlAttTypeEnum *typeEnum = NULL;
	decXmlAttTypeEnumEntry *enumEntry = NULL;
	bool hasNotation = false;
	int lineNumber = pParent->GetTokenLineNumber();
	int posNumber = pParent->GetTokenPositionNumber();
	// EnumeratedType ::= NotationType | Enumeration
	// NotationType ::= 'NOTATION' S '(' S? Name (S? '|' S? Name)* S? ')'
	// Enumeration ::= '(' S? Nmtoken (S? '|' S? Nmtoken)* S? ')'
	try{
		typeEnum = new decXmlAttTypeEnum;
		if( ! typeEnum ) DETHROW( deeOutOfMemory );
		typeEnum->SetLineNumber( lineNumber );
		typeEnum->SetPositionNumber( posNumber );
		hasNotation = pParent->ParseToken( "NOTATION" );
		if( hasNotation && pParent->ParseSpaces() == 0 ) pParent->RaiseFatalError();
		if( ! pParent->ParseToken( "(" ) ) pParent->RaiseFatalError();
		pParent->ParseSpaces();
		lineNumber = pParent->GetTokenLineNumber();
		posNumber = pParent->GetTokenPositionNumber();
		if( hasNotation ){
			pParent->ParseName( 0, true );
		}else{
			pParent->ParseName( 0, true );
		}
		enumEntry = new decXmlAttTypeEnumEntry( pParent->GetCleanString() );
		if( ! enumEntry ) DETHROW( deeOutOfMemory );
		enumEntry->SetLineNumber( lineNumber );
		enumEntry->SetPositionNumber( posNumber );
		typeEnum->AddElement( enumEntry );
		enumEntry = NULL;
		pParent->ParseSpaces();
		while( pParent->ParseToken( "|" ) ){
			pParent->ParseSpaces();
			lineNumber = pParent->GetTokenLineNumber();
			posNumber = pParent->GetTokenPositionNumber();
			if( hasNotation ){
				pParent->ParseName( 0, true );
			}else{
				pParent->ParseName( 0, true );
			}
			enumEntry = new decXmlAttTypeEnumEntry( pParent->GetCleanString() );
			if( ! enumEntry ) DETHROW( deeOutOfMemory );
			enumEntry->SetLineNumber( lineNumber );
			enumEntry->SetPositionNumber( posNumber );
			typeEnum->AddElement( enumEntry );
			enumEntry = NULL;
			pParent->ParseSpaces();
		}
		if( ! pParent->ParseToken( ")" ) ) pParent->RaiseFatalError();
		entry->SetAttributeTypeEnum( typeEnum );
	}catch( const deException & ){
		if( enumEntry ) delete enumEntry;
		if( typeEnum ) delete typeEnum;
		throw;
	}
}
