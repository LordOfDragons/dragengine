/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLCONTAINER_H_
#define _DECXMLCONTAINER_H_

// includes
#include "decXmlElement.h"


// predefinitions


/**
 * @brief XML Container.
 *
 * This is the base class for all XML elements which can
 * contain an unrestricted number of other XML elements.
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 */
class decXmlContainer : public decXmlElement{
private:
	decXmlElement **pElements;
	int pElementCount, pElementSize;
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/** Creates a new xml container. */
	decXmlContainer();
	/** Cleans up the xml container. */
	virtual ~decXmlContainer();
	/*@}*/
	
	/** @name Element Management */
	/*@{*/
	/** Retrieves the count of elements. */
	virtual int GetElementCount() const;
	/** Determines if there are no elements in this container. */
	virtual bool IsEmpty() const;
	/** Retrieves the element at the given index. */
	virtual decXmlElement *GetElementAt( int index ) const;
	/** Adds an element to the container. */
	virtual void AddElement( decXmlElement *element );
	/** Removes an element from the container. */
	virtual void RemoveElement( decXmlElement *element );
	/** Removes all elements from the container. */
	virtual void RemoveAllElements();
	/** Retrieves the index of an element or -1 if not found. */
	virtual int IndexOfElement( decXmlElement *element );
	/** Determines if the given element is part of the container. */
	virtual bool HasElement( decXmlElement *element );
	/** Visits all elements. */
	virtual void VisitElements( decXmlVisitor *visitor );
	/*@}*/
	
	/** @name Visiting */
	/*@{*/
	virtual void Visit( decXmlVisitor *visitor );
	/*@}*/
	
	/** @name Casting */
	/*@{*/
	virtual bool CanCastToContainer();
	virtual decXmlContainer *CastToContainer();
	/*@}*/
};

// end of include only once
#endif
