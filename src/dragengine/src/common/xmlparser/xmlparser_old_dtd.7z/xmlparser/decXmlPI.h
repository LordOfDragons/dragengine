/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLPI_H_
#define _DECXMLPI_H_

// includes
#include "decXmlElement.h"


// predefinitions


/**
 * @brief XML Process Instruction.
 *
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 */
class decXmlPI : public decXmlElement{
private:
	char *pTarget, *pCommand;
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/** Creates a new xml process instruction. */
	decXmlPI( const char *target );
	/** Cleans up the xml process instruction. */
	~decXmlPI();
	/*@}*/
	
	/** @name Management */
	/*@{*/
	inline const char *GetTarget() const{ return (const char *)pTarget; }
	void SetTarget( const char *target );
	inline const char *GetCommand() const{ return (const char *)pCommand; }
	void SetCommand( const char *command );
	/*@}*/
	
	/** @name Visiting */
	/*@{*/
	void Visit( decXmlVisitor *visitor );
	/*@}*/
	
	/** @name Casting */
	/*@{*/
	virtual bool CanCastToPI();
	virtual decXmlPI *CastToPI();
	/*@}*/
};

// end of include only once
#endif
