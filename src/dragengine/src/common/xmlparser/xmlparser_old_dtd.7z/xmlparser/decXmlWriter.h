/* 
 * Drag[en]gine Game Engine
 *
 * Copyright (C) 2009, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef _DECXMLWRITER_H_
#define _DECXMLWRITER_H_

class decString;
class decBaseFileWriter;
class decUnicodeString;



/**
 * \brief Lightweight helper class for writing XML files without using a constructed XML document.
 * \author Plüss Roland
 * \version 1.0
 * \date 2009
 */
class decXmlWriter{
private:
	decBaseFileWriter *pFile;
	int pIndent;
	
public:
	/** \name Constructors and Destructors */
	/*@{*/
	/** \brief Creates a new xml writer. */
	decXmlWriter( decBaseFileWriter *file );
	/** \brief Cleans up the xml writer. */
	~decXmlWriter();
	/*@}*/
	
	/** \name Management */
	/*@{*/
	/** \brief Retrieves the indent level. */
	inline int GetIndent() const{ return pIndent; }
	/** \brief Sets the indent level. */
	void SetIndent( int indent );
	/** \brief Increases the indent level by one. */
	void IncreaseIndent();
	/** \brief Decreases the indent level by one if larger than 0. */
	void DecreaseIndent();
	
	/** \brief Writes the current indent. */
	void WriteIndent();
	
	/** \brief Writes the XML Declaration using UTF-8 as encoding. */
	void WriteXMLDeclaration();
	/** \brief Writes an unicode string in UTF-8 encoding. */
	void WriteUnicodeString( const decUnicodeString &string );
	/** \brief Writes a newline useful for structuring content. Writes first the current indent and then a newline. */
	void WriteNewline();
	
	/** \brief Writes the Document Type Declaration. */
	void WriteDocTypeDeclaration( const char *rootTag, const char *dtdSource );
	/** \brief Writes the Document Type Declaration. */
	void WriteDocTypeDeclaration( const decUnicodeString &rootTag, const decUnicodeString &dtdSource );
	/**
	 * \brief Writes opening tag with no arguments.
	 * \details Writes first the current indent and then '\<NAME>' or '\<NAME/>' without quotes depending
	 *          on the empty parameter. If newline is true a newline is written after the tag. If empty
	 *          is false and newline is true the indent is increased by one.
	 */
	void WriteOpeningTag( const char *name, bool empty = false, bool indent = true, bool newline = true );
	void WriteOpeningTag( const decUnicodeString &name, bool empty = false, bool indent = true, bool newline = true );
	/** \brief Writes the start of an opening tag. Writes first the current indent and then '\<NAME' without quotes. */
	void WriteOpeningTagStart( const char *name, bool indent = true );
	void WriteOpeningTagStart( const decUnicodeString &name, bool indent = true );
	/** \brief Writes a string argument. Writes ' NAME="STRING"' without single quotes. The string value is properly escaped. */
	void WriteAttributeString( const char *name, const char *string );
	void WriteAttributeString( const char *name, const decString &string );
	void WriteAttributeString( const decUnicodeString &name, const decUnicodeString &string );
	/** \brief Writes a boolean argument. Writes ' NAME="VALUE"' without single quotes. */
	void WriteAttributeBool( const char *name, bool value );
	void WriteAttributeBool( const decUnicodeString &name, bool value );
	/** \brief  Writes an integer argument. Writes ' NAME="VALUE"' without single quotes. */
	void WriteAttributeInt( const char *name, int value );
	void WriteAttributeInt( const decUnicodeString &name, int value );
	/**
	 * \brief Writes a float argument. Writes ' NAME="VALUE"' without single quotes. The value is written
	 *        similar to the %g format flag from the printf family of functions.
	 */
	void WriteAttributeFloat( const char *name, float value );
	void WriteAttributeFloat( const decUnicodeString &name, float value );
	/**
	 * \brief Writes a double argument. Writes ' NAME="VALUE"' without single quotes. The value is written
	 *        similar to the %g format flag from the printf family of functions.
	 */
	void WriteAttributeDouble( const char *name, double value );
	void WriteAttributeDouble( const decUnicodeString &name, double value );
	/**
	 * \brief  Writes the end of an opening tag. Writes either "/>" or ">".
	 * \details If empty is true an empty tag using the first text is written otherwise an opening tag with
	 *          the second text. If newline is true a newline is written after the text. If newline is true
	 *          and empty is false the indent is increased by one.
	 */
	void WriteOpeningTagEnd( bool empty = false, bool newline = true );
	/** \brief Writes text with proper escaping. */
	void WriteTextString( const char *text );
	void WriteTextString( const decString &text );
	void WriteTextString( const decUnicodeString &text );
	/** \brief Writes bool text. */
	void WriteTextBool( bool value );
	/** \brief Writes integer text. */
	void WriteTextInt( int value );
	/** \brief Writes float text. */
	void WriteTextFloat( float value );
	/** \brief Writes double text. */
	void WriteTextDouble( double value );
	/**
	 * \brief Writes a closing tag.
	 * \details Writes first the current indent and then '\</NAME>' without the quotes. If newline is true
	 *          a newline is written after the closing tag and the indent decreased by one.
	 */
	void WriteClosingTag( const char *name, bool indent = true, bool newline = true );
	void WriteClosingTag( const decUnicodeString &name, bool indent = true, bool newline = true );
	/** \brief Writes a comment. */
	void WriteComment( const char *comment, bool indent = true, bool newline = true );
	void WriteComment( const decString &comment, bool indent = true, bool newline = true );
	void WriteComment( const decUnicodeString &comment, bool indent = true, bool newline = true );
	
	/**
	 * \brief Writes an entire data text tag.
	 * \details A data tag composes of an opening tag with no parameters, a text and an ending tag on the
	 *          same line ( if the text is not multi line ).
	 */
	void WriteDataTagString( const char *tagName, const char *string, bool indent = true, bool newline = true );
	void WriteDataTagString( const char *tagName, const decString &string, bool indent = true, bool newline = true );
	void WriteDataTagString( const decUnicodeString &tagName, const decUnicodeString &string, bool indent = true, bool newline = true );
	/**
	 * \brief Writes an entire boolean data tag.
	 * \details A data tag composes of an opening tag with no parameters, a text and an ending tag on
	 *          the same line ( if the text is not multi line ).
	 */
	void WriteDataTagBool( const char *tagName, bool value, bool indent = true, bool newline = true );
	void WriteDataTagBool( const decUnicodeString &tagName, bool value, bool indent = true, bool newline = true );
	/**
	 * \brief Writes an entire integer data tag.
	 * \details A data tag composes of an opening tag with no parameters, a text and an ending tag on
	 *          the same line ( if the text is not multi line ).
	 */
	void WriteDataTagInt( const char *tagName, int value, bool indent = true, bool newline = true );
	void WriteDataTagInt( const decUnicodeString &tagName, int value, bool indent = true, bool newline = true );
	/**
	 * \brief Writes an entire float data tag.
	 * \details A data tag composes of an opening tag with no parameters, a text and an ending tag on
	 *          the same line ( if the text is not multi line ).
	 */
	void WriteDataTagFloat( const char *tagName, float value, bool indent = true, bool newline = true );
	void WriteDataTagFloat( const decUnicodeString &tagName, float value, bool indent = true, bool newline = true );
	/**
	 * \brief Writes an entire double data tag.
	 * \details A data tag composes of an opening tag with no parameters, a text and an ending tag on
	 *          the same line ( if the text is not multi line ).
	 */
	void WriteDataTagDouble( const char *tagName, double value, bool indent = true, bool newline = true );
	void WriteDataTagDouble( const decUnicodeString &tagName, double value, bool indent = true, bool newline = true );
	/*@}*/
};

#endif
