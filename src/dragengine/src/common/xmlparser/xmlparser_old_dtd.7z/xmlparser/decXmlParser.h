/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// include only once
#ifndef _DECXMLPARSER_H_
#define _DECXMLPARSER_H_


// declerations
#define DEXP_EOF			0x100


// includes

// predefinitions
class decXmlDocument;
class decXmlComment;
class decXmlContainer;
class decXmlElement;
class decXmlVisitor;
class decXmlDTD;
class decXmlElementDecl;
class decXmlElementDeclOp;
class decXmlAttListDecl;
class decXmlAttListDeclEntry;
class decXmlAttValue;
class decBaseFileReader;
class deLogger;



/**
 * @brief XML Parser.
 *
 * The XML Paser processes an XML file provided by a file reader
 * object. The content of the file is parsed and syntax checked
 * but not validated. The resulting XML tree is then available
 * in the document. One parser can not parse two XML files at
 * the same time.
 *
 * A typical scenario looks like this:
 * @code decXMLParser parser;
 * decXmlDocument document;
 * if( parser.ParseXml( myFileReader, &document ) ){
 *     // success
 * }else{
 *     // failure
 * }
 * @endcode
 *
 * Errors occuring during parsing the XML file can be captured
 * by overwriting the error handling functions.
 * @todo
 * - Add Schema support
 * - Add Validation support for DTD and Schema
 * @author Plüss Roland
 * @version 1.0
 * @date 2008
 */
class decXmlParser{
private:
	// parsing
	decBaseFileReader *pFile;
	int pLine, pPos, pCurChar;
	char *pToken;
	int pTokenLen, pTokenSize;
	int pTokenLine, pTokenPos;
	char *pCleanString;
	int pCleanStringSize;
	int pFilePos, pFileLen;
	// error handling
	deLogger *pLogger;
	bool pHasFatalError;
	
public:
	/** @name Constructors and Destructors */
	/*@{*/
	/** Creates a new xml parser. */
	decXmlParser( deLogger *logger );
	/** Cleans up the xml parser. */
	virtual ~decXmlParser();
	/*@}*/
	
	/** @name Management */
	/*@{*/
	/**
	 * Parses the XML file using the given file reader into the given
	 * document object. Only one XML file can be processed at the same
	 * time. Calling ParseXML on the same parser while one instance
	 * is running results in the second invokation to fail.
	 * @return true on success or false otherwise
	 */
	bool ParseXml( decBaseFileReader *file, decXmlDocument *doc );
	/*@}*/
	
	/**
	 * @name Error Handling
	 * Those functions are provided to allow applications to capture all
	 * errors during parsing time. Simply overwrite the functions you
	 * are interested in.
	 */
	/*@{*/
	/**
	 * The end of the XML file has been reached although not allowed yet.
	 * @param line Line number where the error occured
	 * @param pos Position from the beginning of the line where the error occured.
	 */
	virtual void UnexpectedEOF( int line, int pos );
	/**
	 * A token has been parse that is not expected at this place.
	 * @param line Line number where the error occured
	 * @param pos Position from the beginning of the line where the error occured.
	 * @param token The unexpected token in unparsed form
	 */
	virtual void UnexpectedToken( int line, int pos, const char *token );
	/*@}*/
	
	/**
	 * @name Parsing Functions
	 * Those functions are used only by the ParseXml and should not be called
	 * directly except you want to write an extended XML parser.
	 */
	/*@{*/
	/** Prepares parsing the file by reseting all counters. */
	void PrepareParse( decBaseFileReader *file );
	/** Parses an XML file. */
	void ParseDocument( decXmlDocument *doc );
	/** Parses the XML file prolog. */
	void ParseProlog( decXmlDocument *doc );
	/** Parses an XML Declaration. */
	void ParseXMLDecl( decXmlDocument *doc );
	/** Parses a document type declaration. */
	void ParseDocTypeDecl( decXmlDocument *doc );
	/** Parses a system literal. */
	void ParseSystemLiteral( decXmlDocument *doc );
	/** Parses a public literal. */
	void ParsePublicLiteral( decXmlDocument *doc );
	/**
	 * Parses a DTD if one exists.
	 * @return true if a DTD has been parsed
	 */
	bool ParseDTD( decXmlDTD *dtd );
	/**
	 * Parses an element tag but only if the tag name matches requiredName.
	 * @return true if an element tag has been parsed
	 */
	bool ParseElementTag( decXmlContainer *container, const char *requiredName );
	/**
	 * Parses a reference if one exists.
	 * @return true if a reference has been parsed
	 */
	bool ParseReference( decXmlContainer *container );
	/**
	 * Parses a cd section if one exists.
	 * @return true if a cd section has been parsed
	 */
	bool ParseCDSect( decXmlContainer *container );
	/** Parses an attribute. */
	void ParseAttribute( decXmlContainer *container );
	/** Parses an attribute value. */
	void ParseAttValue( decXmlAttValue *value );
	/**
	 * Checks if the next token matches a certain name. If found the
	 * token is consumed.
	 * @return true if the expected token has been found
	 */
	bool ParseToken( const char *expected );
	/** Parses a value assignement. */
	void ParseEquals();
	/** Parses white spaces and returns the number of white spaces found. */
	int ParseSpaces();
	/** Parses an enconding name. */
	void ParseEncName( decXmlDocument *doc );
	/** Parses any number of consequtive comments, pi or white spaces. */
	void ParseMisc( decXmlContainer *container );
	/**
	 * Parses a comment if present.
	 * @return true if a comment has been parsed
	 */
	bool ParseComment( decXmlContainer *container );
	/**
	 * Parses a process instruction if present.
	 * @return true if a process instruction has been parsed
	 */
	bool ParsePI( decXmlContainer *container );
	/**
	 * Parses a name token. The parsing starts offset character ahead of
	 * the current position. If a valid name token has been parse it is
	 * removed only if autoRemove is true.
	 * @return offset to the last character in the token measured from
	 *         the current position.
	 */
	int ParseName( int offset, bool autoRemove );
	/** Determines if the token starting offset characters ahead of the current position matches a given name. */
	bool TestToken( int offset, const char *expected );
	/*@}*/
	
	/** @name Testing */
	/*@{*/
	bool IsLatinLetter( int aChar );
	bool IsLatinDigit( int aChar );
	bool IsHex( int aChar );
	bool IsLetter( int aChar );
	bool IsDigit( int aChar );
	bool IsExtender( int aChar );
	bool IsBaseChar( int aChar );
	bool IsCombiningChar( int aChar );
	bool IsIdeographic( int aChar );
	bool IsChar( int aChar );
	bool IsPubidChar( int aChar, bool restricted );
	bool IsSpace( int aChar );
	/*@}*/
	
	/** @name Token Management */
	/*@{*/
	/**
	 * Retrieves the character at the given index ahead from the current position.
	 * If the token buffer does not hold this character yet all characters up to
	 * this position are read into the token buffer.
	 */
	/** Retrieves the line number of the current token. */
	inline int GetTokenLineNumber() const{ return pTokenLine; }
	/** Retrieves the position number of the current token. */
	inline int GetTokenPositionNumber() const{ return pTokenPos; }
	int GetTokenAt( int index );
	/** Clears the current token buffer. */
	void ClearToken();
	/** Removes the given number of characters from the beginning of the token buffer. */
	void RemoveFromToken( int length );
	/** Adds a character to the token buffer. */
	void AddCharToToken( int aChar );
	/** Determines if the current position is at the end of the xml file. */
	bool IsEOF();
	/** Raises a fatal error by first calling the approriate error handler and then throwing an exception. */
	void RaiseFatalError();
	/*@}*/
	
	/** @name Management */
	/*@{*/
	/** Retrieves the clean string buffer. */
	inline const char *GetCleanString() const{ return (const char *)pCleanString ; }
	/** Copyies the indicates number of characters from the token buffer to the clean string buffer null terminated. */
	void SetCleanString( int length );
	/*@}*/
private:
	void pGetNextChar();
	void pGetNextCharAndAdd();
	void pGrowToken();
	void pAddCharacterData( decXmlContainer *container, const char *text, int line, int pos );
	void pAddCharacterData( decXmlContainer *container, char character, int line, int pos );
};

// end of include only once
#endif
