/* 
 * Drag[en]gine Library -- Game Engine
 *
 * Copyright (C) 2008, Plüss Roland ( roland@rptd.ch )
 * 
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License 
 * as published by the Free Software Foundation; either 
 * version 2 of the License, or (at your option) any later 
 * version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

// includes
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decXmlPI.h"
#include "decXmlVisitor.h"
#include "../exceptions.h"



// class decXmlPI
////////////////////////

// constructor, destructor
decXmlPI::decXmlPI( const char *target ){
	pTarget = NULL;
	pCommand = NULL;
	try{
		SetTarget( target );
		pCommand = new char[ 1 ];
		if( ! pCommand ) DETHROW( deeOutOfMemory );
		pCommand[ 0 ] = '\0';
	}catch( const deException & ){
		if( pCommand ) delete [] pCommand;
		if( pTarget ) delete [] pTarget;
		throw;
	}
}
decXmlPI::~decXmlPI(){
	if( pCommand ) delete [] pCommand;
	if( pTarget ) delete [] pTarget;
}

// management
void decXmlPI::SetTarget( const char *target ){
	if( ! target ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( target ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, target );
	if( pTarget ) delete [] pTarget;
	pTarget = newStr;
}
void decXmlPI::SetCommand( const char *command ){
	if( ! command ) DETHROW( deeInvalidParam );
	char *newStr = new char[ strlen( command ) + 1 ];
	if( ! newStr ) DETHROW( deeOutOfMemory );
	strcpy( newStr, command );
	if( pCommand ) delete [] pCommand;
	pCommand = newStr;
}

// visiting
void decXmlPI::Visit( decXmlVisitor *visitor ){
	if( ! visitor ) DETHROW( deeInvalidParam );
	visitor->VisitPI( this );
}

// casting
bool decXmlPI::CanCastToPI(){
	return true;
}
decXmlPI *decXmlPI::CastToPI(){
	return this;
}
